# Rust Multimedia Browser

A compact GTK4 + WebKitGTK browser in Rust with HTML5 multimedia enabled.

## What it includes

- Address bar with URL normalization and search fallback
- Back / forward / reload / stop / home
- Zoom controls
- Mute toggle
- Progress bar and status line
- HTML5 media-oriented WebKit settings enabled

## Linux build requirements

For Ubuntu or Debian-like systems, install the GTK4, WebKitGTK 6.0, JavaScriptCore 6.0, and GStreamer development/runtime packages first:

```bash
sudo apt update
sudo apt install -y \
  build-essential pkg-config curl git \
  libgtk-4-dev \
  libwebkitgtk-6.0-dev \
  libjavascriptcoregtk-6.0-dev \
  libgstreamer1.0-dev \
  libgstreamer-plugins-base1.0-dev \
  gstreamer1.0-libav \
  gstreamer1.0-plugins-base \
  gstreamer1.0-plugins-good \
  gstreamer1.0-plugins-bad \
  gstreamer1.0-plugins-ugly
```

Then install Rust if needed and run:

```bash
cargo run --release
```

## Notes

- This project relies on the system WebKitGTK engine and installed codecs.
- DRM/Widevine support is outside the scope of this minimal checked build.
- Camera, microphone, and location permission requests are denied by default for safety.
